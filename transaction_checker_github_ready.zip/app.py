
import streamlit as st
import pandas as pd
import io

st.markdown("""
    <style>
    .main {
        background-color: #f4f6f8;
        padding: 20px;
        font-family: 'Segoe UI', sans-serif;
    }
    h1, h2, h3 {
        color: #1f4e79;
    }
    .stButton>button {
        background-color: #1f4e79;
        color: white;
        border: None;
        padding: 8px 20px;
        font-size: 16px;
    }
    .stTextInput>div>div>input {
        background-color: #ffffff;
        padding: 6px;
        border: 1px solid #d4d4d4;
    }
    </style>
""", unsafe_allow_html=True)


st.set_page_config(page_title="Transaction Checker", layout="centered")

tab1, tab2, tab3, tab4 = st.tabs([
    "🧾 Transaction Status Checker", 
    "🛠️ Column Management", 
    "✏️ Transaction Modifier", 
    "📂 File Merger"
])

with tab1:
    st.title("Transaction Status Checker (TP1 vs TP2)")

    uploaded_file = st.file_uploader("Upload Excel File", type=["xlsx"], key="compare")
    if uploaded_file:
        xls = pd.ExcelFile(uploaded_file)
        sheet_names = xls.sheet_names

        if "TP1" in sheet_names and "TP2" in sheet_names:
            tp1 = pd.read_excel(xls, sheet_name="TP1")
            tp2 = pd.read_excel(xls, sheet_name="TP2")

            tp1['Merchant Transaction Id'] = tp1['Merchant Transaction Id'].astype(str)
            tp2['Merchant Transaction Id'] = tp2['Merchant Transaction Id'].astype(str)

            merged = tp2.merge(tp1[['Merchant Transaction Id', 'Status']], on='Merchant Transaction Id', how='left')
            merged['Status'] = merged['Status'].fillna('Not Found')

            st.success("✅ Comparison complete!")
            st.dataframe(merged)

            output = io.BytesIO()
            merged.to_excel(output, index=False, engine='openpyxl')
            st.download_button(
                label="📥 Download Result Excel",
                data=output.getvalue(),
                file_name="Compared_Status.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        else:
            st.error("❌ Excel file must have sheets named 'TP1' and 'TP2' (with space).")

with tab2:
    st.title("Column Management")

    manage_file = st.file_uploader("Upload Excel to Keep Only Two Columns", type=["xlsx"], key="column")
    if manage_file:
        df = pd.read_excel(manage_file)

        expected_cols = ['Merchant Transaction Id', 'Status']
        filtered_df = df[[col for col in expected_cols if col in df.columns]]

        st.success("✅ Columns trimmed successfully!")
        st.dataframe(filtered_df)

        output_filtered = io.BytesIO()
        filtered_df.to_excel(output_filtered, index=False, engine='openpyxl')
        st.download_button(
            label="📥 Download Trimmed Excel",
            data=output_filtered.getvalue(),
            file_name="Filtered_Columns.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

with tab3:
    st.title("Transaction Modifier")

    transactions_input = st.text_area("Paste Transaction IDs (one per line)")
    if st.button("Generate Excel File"):
        transaction_list = [line.strip() for line in transactions_input.strip().splitlines() if line.strip()]
        if transaction_list:
            df = pd.DataFrame(transaction_list, columns=["Merchant Transaction Id"])

            output_tp2 = io.BytesIO()
            with pd.ExcelWriter(output_tp2, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name="TP2")

            st.success("✅ Excel file generated!")
            st.download_button(
                label="📥 Download TP2 Excel",
                data=output_tp2.getvalue(),
                file_name="TP2.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        else:
            st.warning("⚠️ Please paste at least one transaction ID.")

with tab4:
    st.title("File Merger")

    file_tp1 = st.file_uploader("Upload File with 'Merchant Transaction Id' and 'Status' (TP1)", type=["xlsx"], key="merge_tp1")
    file_tp2 = st.file_uploader("Upload File with only 'Merchant Transaction Id' (TP2)", type=["xlsx"], key="merge_tp2")

    if file_tp1 and file_tp2:
        try:
            df_tp1 = pd.read_excel(file_tp1)
            df_tp2 = pd.read_excel(file_tp2)

            # Check required columns
            if 'Merchant Transaction Id' in df_tp1.columns and 'Status' in df_tp1.columns and 'Merchant Transaction Id' in df_tp2.columns:
                output_merge = io.BytesIO()
                with pd.ExcelWriter(output_merge, engine='openpyxl') as writer:
                    df_tp1.to_excel(writer, index=False, sheet_name="TP1")
                    df_tp2.to_excel(writer, index=False, sheet_name="TP2")

                st.success("✅ Files merged successfully!")
                st.download_button(
                    label="📥 Download Merged Excel",
                    data=output_merge.getvalue(),
                    file_name="Merged_TP1_TP2.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            else:
                st.error("❌ One or both files are missing required columns.")
        except Exception as e:
            st.error(f"⚠️ Error: {str(e)}")